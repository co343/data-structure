/**
 * Author:  TripleZ<me@triplez.cn>
 * Date:    2018-10-10
 * Brief:   ListNode class.
 */

#ifndef _LISTNODE_HPP_
#define _LISTNODE_HPP_

class ListNode {
public:
    int val;
    ListNode *next;
};

#endif
