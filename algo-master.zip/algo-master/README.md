# 数据结构和算法之美
# [https://time.geekbang.org/column/intro/126](https://time.geekbang.org/column/intro/126)

# Java rate limiting library/framework
# https://github.com/wangzheng0822/ratelimiter4j
