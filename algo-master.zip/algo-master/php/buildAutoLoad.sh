#!/bin/bash

composer dump-autoload